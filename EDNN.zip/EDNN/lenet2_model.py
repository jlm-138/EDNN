import tensorflow as tf
import gecm_layers
import decision_layers
import loss


def my_model1():
    prototypes = 10
    num_class = 10
    alpha = 1.
    p = 0.5
    lam = 0.1

    input_img = tf.keras.layers.Input([28, 28, 1], name="img")
    input_lbl = tf.keras.layers.Input([num_class], name="lbl")

    c1_1 = tf.keras.layers.Conv2D(32, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(input_img)
    c1_2 = tf.keras.layers.Conv2D(32, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(c1_1)
    p1 = tf.keras.layers.MaxPooling2D((2, 2))(c1_2)

    c2_1 = tf.keras.layers.Conv2D(64, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(p1)
    c2_2 = tf.keras.layers.Conv2D(64, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(c2_1)
    p2 = tf.keras.layers.MaxPooling2D((2, 2))(c2_2)

    c3_1 = tf.keras.layers.Conv2D(128, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(p2)
    c3_2 = tf.keras.layers.Conv2D(128, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(c3_1)
    p3 = tf.keras.layers.MaxPooling2D((2, 2))(c3_2)

    flatten1 = tf.keras.layers.Flatten()(p3)
    feature = tf.keras.layers.Dense(2, activation=None)(flatten1)

    ED = gecm_layers.Distance(prototypes, 2)(feature)
    ED_ac = gecm_layers.DS1_activate(alpha)(ED)
    mass_prototypes = gecm_layers.DS2_mass()(ED_ac)
    mass_with_omega = gecm_layers.DS2_mass_omega()(mass_prototypes)
    mass = gecm_layers.DS3_Dempster_mass(num_class)(mass_with_omega)
    outputs = decision_layers.DM_train(p, num_class)(mass)

    my_loss = loss.pl_loss(lam)([input_lbl, ED, outputs])

    model = tf.keras.Model(inputs=[input_img, input_lbl], outputs=[outputs, my_loss])
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001), run_eagerly=True)
    return model


def my_model2():
    prototypes = 8
    num_class = 8
    alpha = 1.
    p = 0.5
    lam = 0.1

    input_img = tf.keras.layers.Input([28, 28, 1], name="img")
    input_lbl = tf.keras.layers.Input([num_class], name="lbl")

    c1_1 = tf.keras.layers.Conv2D(32, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(input_img)
    c1_2 = tf.keras.layers.Conv2D(32, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(c1_1)
    p1 = tf.keras.layers.MaxPooling2D((2, 2))(c1_2)

    c2_1 = tf.keras.layers.Conv2D(64, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(p1)
    c2_2 = tf.keras.layers.Conv2D(64, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(c2_1)
    p2 = tf.keras.layers.MaxPooling2D((2, 2))(c2_2)

    c3_1 = tf.keras.layers.Conv2D(128, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(p2)
    c3_2 = tf.keras.layers.Conv2D(128, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(c3_1)
    p3 = tf.keras.layers.MaxPooling2D((2, 2))(c3_2)

    flatten1 = tf.keras.layers.Flatten()(p3)
    feature = tf.keras.layers.Dense(2, activation=None)(flatten1)

    ED = gecm_layers.Distance(prototypes, 2)(feature)
    ED_ac = gecm_layers.DS1_activate(alpha)(ED)
    mass_prototypes = gecm_layers.DS2_mass()(ED_ac)
    mass_with_omega = gecm_layers.DS2_mass_omega()(mass_prototypes)
    mass = gecm_layers.DS3_Dempster_mass(num_class)(mass_with_omega)
    outputs = decision_layers.DM_train(p, num_class)(mass)

    my_loss = loss.pl_loss(lam)([input_lbl, ED, outputs])

    model = tf.keras.Model(inputs=[input_img, input_lbl], outputs=[outputs, my_loss])
    model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001), run_eagerly=True)
    return model
import tensorflow as tf
from tensorflow import keras
from keras.datasets import mnist
from scipy.optimize import minimize
import math
import numpy as np
import gecm_layers
import decision_layers

(x_train, y_train), (x_test, y_test) = mnist.load_data()
x_test = x_test.astype("float32") / 255.0
y_test_label = y_test
y_test = keras.utils.to_categorical(y_test)


# aim func: cross entropy
def func(x):
    fun = 0
    for i in range(len(x)):
        fun += x[i] * math.log10(x[i])
    return fun


# constraint 1: the sum of weights is 1
def cons1(x):
    return sum(x)


# constraint 2: define tolerance to imprecision
def cons2(x):
    tol = 0
    for i in range(len(x)):
        tol += (len(x) - (i + 1)) * x[i] / (len(x) - 1)
    return tol


# compute the weights g for ordered weighted average aggreagtion
num_class = 10
for j in range(2, (num_class+1)):
    num_weights = j
    ini_weights = np.asarray(np.random.rand(num_weights))
    name = 'weight' + str(j)
    locals()['weight'+str(j)] = np.zeros([5, j])
    for i in range(5):
        tol = 0.5 + i * 0.1
        cons = ({'type': 'eq', 'fun': lambda x: cons1(x)-1},
              {'type': 'eq', 'fun': lambda x: cons2(x)-tol},
              {'type': 'ineq', 'fun': lambda x: x-0.00000001}
            )
        res = minimize(func, ini_weights, method='SLSQP', options={'disp': True}, constraints=cons)
        locals()['weight'+str(j)][i] = res.x
        print(res.x)


# function for power set
def PowerSetsBinary(items):
    N = len(items)
    set_all = []
    for i in range(2**N):
        combo = []
        for j in range(N):
            if(i >> j) % 2 == 1:
                combo.append(items[j])
        set_all.append(combo)
    return set_all


class_set = list(range(num_class))
act_set = PowerSetsBinary(class_set)
act_set_all = sorted(act_set)
act_set.remove(act_set[0])
act_set = sorted(act_set)
# print(act_set_all)
print(len(act_set_all))
# print(act_set)
print(len(act_set))

utility_matrix = np.zeros([len(act_set), len(class_set)])
tol_i = 4
# tol_i = 0 with tol=0.5, tol_i = 1 with tol=0.6, tol_i = 2 with tol=0.7, tol_i = 3 with tol=0.8, tol_i = 4 with tol=0.9
for i in range(len(act_set)):
    intersec = class_set and act_set[i]
    if len(intersec) == 1:
        utility_matrix[i, intersec] = 1
    else:
        for j in range(len(intersec)):
            utility_matrix[i, intersec[j]] = locals()['weight'+str(len(intersec))][tol_i, 0]
h = np.zeros([len(act_set), 1])
utility_matrix = np.hstack((h, utility_matrix))
v = np.zeros([1, len(class_set)+1])
# v[0, 0] = 1
utility_matrix = np.vstack((v, utility_matrix))
print(utility_matrix)

prototypes = 10
num_class = 10
alpha = 1.
p = 0.5
number_act_set = len(act_set_all)

input_img = tf.keras.layers.Input([28, 28, 1], name="img")

c1_1 = tf.keras.layers.Conv2D(32, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(input_img)
c1_2 = tf.keras.layers.Conv2D(32, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(c1_1)
p1 = tf.keras.layers.MaxPooling2D((2, 2))(c1_2)

c2_1 = tf.keras.layers.Conv2D(64, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(p1)
c2_2 = tf.keras.layers.Conv2D(64, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(c2_1)
p2 = tf.keras.layers.MaxPooling2D((2, 2))(c2_2)

c3_1 = tf.keras.layers.Conv2D(128, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(p2)
c3_2 = tf.keras.layers.Conv2D(128, (5, 5), activation='relu', kernel_initializer='he_normal', padding='same')(c3_1)
p3 = tf.keras.layers.MaxPooling2D((2, 2))(c3_2)

flatten1 = tf.keras.layers.Flatten()(p3)
feature = tf.keras.layers.Dense(2, activation=None)(flatten1)

ED = gecm_layers.Distance(prototypes, 2)(feature)
ED_ac = gecm_layers.DS1_activate(alpha)(ED)
mass_prototypes = gecm_layers.DS2_mass()(ED_ac)
mass_with_omega = gecm_layers.DS2_mass_omega()(mass_prototypes)
mass = gecm_layers.DS3_Dempster_mass(num_class)(mass_with_omega)

outputs = decision_layers.DM_test(num_class, number_act_set, p)(mass)

model_e_imprecise = tf.keras.Model(inputs=[input_img], outputs=[outputs])
model_e_imprecise.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.001))
model_e_imprecise.summary()

model_e_imprecise.layers[-1].set_weights(tf.reshape(utility_matrix, [1, 1024, 11]))
model_e_imprecise.load_weights('weights_mnist10/ednn_mnist10_lam0.1_p0.5_checkpoint')

results = tf.argmax(model_e_imprecise.predict(x_test), -1)
imprecise_results = []
for i in range(len(results)):
    act_local = results[i]
    set_valued_results = act_set_all[act_local]
    imprecise_results.append(set_valued_results)
print("\nset-valued results:\n", imprecise_results)


def average_utility(utility_matrix, inputs, labels):
    utility = 0
    for i in range(len(inputs)):
        x = inputs[i]
        y = labels[i]
        utility += utility_matrix[x, y+1]
    average_utility = utility / len(inputs)
    return average_utility


average_utility_imprecision = average_utility(utility_matrix, results, y_test_label)
print("\naverage utility:", average_utility_imprecision)

number = 0
for i in range(len(imprecise_results)):
    number = number + len(imprecise_results[i])
average_c = tf.divide(number, len(imprecise_results), name=None)
print('average cardinality: ', average_c)

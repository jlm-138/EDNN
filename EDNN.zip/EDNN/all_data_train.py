import tensorflow as tf
from tensorflow import keras
from keras.datasets import mnist
from keras.callbacks import ModelCheckpoint
import numpy as np
import lenet2_model

if tf.config.list_physical_devices('GPU'):
    print("GPU is available")
else:
    print("GPU is NOT available")

gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        tf.config.experimental.set_visible_devices(gpus[0], 'GPU')

        (x_train, y_train), (x_test, y_test) = mnist.load_data()
        x_train = np.reshape(x_train, (-1, 28, 28, 1))
        y_train = np.reshape(y_train, (-1, 1))
        x_test = np.reshape(x_test, (-1, 28, 28, 1))
        y_test = np.reshape(y_test, (-1, 1))

        x_train = x_train.astype("float32") / 255.0
        x_test = x_test.astype("float32") / 255.0

        y_train_label = y_train
        y_train_label = tf.expand_dims(y_train_label, axis=-1)
        y_test_label = y_test
        y_test_label = tf.expand_dims(y_test_label, axis=-1)
        y_train = keras.utils.to_categorical(y_train)
        y_test = keras.utils.to_categorical(y_test)


        def map_fn(img, lbl):
            inputs = {"img": img, "lbl": lbl}
            targets = {}
            return inputs, targets


        train_selected = tf.data.Dataset.from_tensor_slices((x_train, y_train)).map(map_fn).shuffle(10000).batch(200)
        test_selected = tf.data.Dataset.from_tensor_slices((x_test, y_test)).map(map_fn).batch(200)

        model_e = lenet2_model.my_model1()
        model_e.summary()

        # define your own filepath to save the weights of the classifier
        filepath = 'weights_mnist10/ednn_mnist10_lam0.1_p0.5_checkpoint'
        checkpoint_callback = ModelCheckpoint(
            filepath, monitor='val_accuracy', verbose=1,
            save_best_only=True, save_weights_only=True,
            save_frequency=1)

        model_e.fit(train_selected, epochs=60, verbose=1, callbacks=[checkpoint_callback], validation_data=(test_selected))
    except RuntimeError as e:
        print(e)
else:
    print("No GPU devices found")

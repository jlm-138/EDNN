import tensorflow as tf
from tensorflow import keras


class pl_loss(tf.keras.layers.Layer):
    def __init__(self, lam):
        super(pl_loss, self).__init__()
        self.lam = lam   # lam is the hyper-parameter which controls the weight of prototype loss

    def call(self, inputs):
        y_true, y_weight, y_pred = inputs

        loss_single = tf.multiply(y_true, tf.math.log(tf.clip_by_value(y_pred, 1e-10, 1.0)), name=None)
        loss_single = -tf.reduce_sum(loss_single, axis=-1)
        ce_loss = tf.reduce_mean(loss_single)

        pl_loss = tf.reduce_sum(y_true * y_weight, -1)
        pl_loss = tf.reduce_mean(pl_loss)

        total_loss = ce_loss + self.lam * pl_loss

        # metric
        acc = keras.metrics.categorical_accuracy(y_true, y_pred)
        self.add_loss(total_loss, inputs=True)
        self.add_metric(acc, name="accuracy")
        return total_loss
